const initialMatrix = [
  { name: 'Hardware', demand: 2.0, values: [0.15, 0.10, 0.20, 0.05, 0.10] },
  { name: 'Cloud / dados', demand: 1.5, values: [0.10, 0.40, 0.15, 0.08, 0.12] },
  { name: 'Automação', demand: 0.8, values: [0.05, 0.15, 0.20, 0.03, 0.15] },
  { name: 'Papel / celulose', demand: 1.2, values: [0.02, 0.05, 0.03, 0.30, 0.08] },
  { name: 'TI verde', demand: 0.5, values: [0.08, 0.12, 0.10, 0.04, 0.05] }
];
const matrix = structuredClone(initialMatrix);
const users = [];
const head = document.querySelector('#matrix-head');
const body = document.querySelector('#matrix-body');
const totalEl = document.querySelector('#production-total');
const toast = document.querySelector('#toast');
let toastTimer;
let editingUser = null;
const fmt = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const esc = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

function notify(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 3400);
}
function renderMatrix() {
  const cols = matrix.map(row => row.name);
  head.innerHTML = '<tr><th>SETOR / INSUMO</th>' + cols.map(name => '<th>' + esc(name.toUpperCase()) + '</th>').join('') + '<th>DEMANDA d</th><th aria-label="Ações"></th></tr>';
  body.innerHTML = matrix.map((row, i) => '<tr><td><span class="sector-mark ' + ['','gold','blue','violet'][i % 4] + '"></span>' + esc(row.name) + '</td>' + row.values.map((value, j) => '<td><input class="coefficient-input" aria-label="Coeficiente ' + esc(row.name) + ' para ' + esc(cols[j]) + '" type="number" min="0" max="0.99" step="0.01" value="' + Number(value).toFixed(2) + '" data-row="' + i + '" data-col="' + j + '"></td>').join('') + '<td><input class="demand-input" aria-label="Demanda de ' + esc(row.name) + '" type="number" min="0" step="0.1" value="' + Number(row.demand).toFixed(1) + '" data-demand="' + i + '"></td><td><button class="delete-sector" aria-label="Excluir setor ' + esc(row.name) + '" data-delete="' + i + '">×</button></td></tr>').join('');
  body.querySelectorAll('.coefficient-input').forEach(input => input.addEventListener('change', event => {
    const value = Number(event.target.value);
    if (!Number.isFinite(value) || value < 0 || value >= 1) { event.target.value = matrix[event.target.dataset.row].values[event.target.dataset.col].toFixed(2); notify('Use um coeficiente entre 0 e 0,99.'); return; }
    matrix[event.target.dataset.row].values[event.target.dataset.col] = value;
    updateProduction();
  }));
  body.querySelectorAll('.demand-input').forEach(input => input.addEventListener('change', event => {
    const value = Number(event.target.value);
    if (!Number.isFinite(value) || value < 0) { event.target.value = matrix[event.target.dataset.demand].demand.toFixed(1); return; }
    matrix[event.target.dataset.demand].demand = value;
    updateProduction();
  }));
  body.querySelectorAll('[data-delete]').forEach(button => button.addEventListener('click', () => {
    if (matrix.length <= 1) { notify('A matriz precisa manter pelo menos um setor.'); return; }
    matrix.splice(Number(button.dataset.delete), 1);
    renderMatrix();
    notify('Setor removido da matriz.');
  }));
  document.querySelector('.matrix-version').textContent = matrix.length + ' setores';
  updateProduction();
}
function updateProduction() {
  const n = matrix.length;
  const a = matrix.map((row, i) => row.values.map((value, j) => (i === j ? 1 : 0) - (value || 0)));
  const x = matrix.map(row => Number(row.demand) || 0);
  let valid = true;
  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let row = col + 1; row < n; row++) if (Math.abs(a[row][col]) > Math.abs(a[pivot][col])) pivot = row;
    if (Math.abs(a[pivot][col]) < 1e-10) { valid = false; break; }
    [a[col], a[pivot]] = [a[pivot], a[col]];
    [x[col], x[pivot]] = [x[pivot], x[col]];
    const divisor = a[col][col];
    for (let j = col; j < n; j++) a[col][j] /= divisor;
    x[col] /= divisor;
    for (let row = 0; row < n; row++) if (row !== col) {
      const factor = a[row][col];
      for (let j = col; j < n; j++) a[row][j] -= factor * a[col][j];
      x[row] -= factor * x[col];
    }
  }
  const total = x.reduce((sum, value) => sum + value, 0);
  totalEl.textContent = valid && Number.isFinite(total) ? fmt.format(total) : 'Matriz inválida';
}
function renderUsers() {
  const table = document.querySelector('#team-body');
  if (!users.length) {
    table.innerHTML = '<tr class="empty-row"><td colspan="4">Nenhum acesso cadastrado nesta sessão.</td></tr>';
    return;
  }
  table.innerHTML = users.map((user, i) => '<tr><td><div class="team-user"><span class="team-avatar">' + esc(user.name.split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase()) + '</span><span><strong>' + esc(user.name) + '</strong><small>' + esc(user.email) + '</small></span></div></td><td><span class="role-pill">' + esc(user.role) + '</span></td><td>' + esc(user.department) + '</td><td><span class="row-actions"><button aria-label="Editar ' + esc(user.name) + '" data-edit-user="' + i + '">Editar</button><button aria-label="Remover ' + esc(user.name) + '" data-remove-user="' + i + '">Remover</button></span></td></tr>').join('');
  table.querySelectorAll('[data-edit-user]').forEach(button => button.addEventListener('click', () => {
    editingUser = Number(button.dataset.editUser);
    const user = users[editingUser];
    const form = document.querySelector('#register-form');
    form.elements.name.value = user.name;
    form.elements.email.value = user.email;
    form.elements.role.value = user.role;
    form.elements.department.value = user.department;
    form.querySelector('h2').textContent = 'Editar cadastro';
    form.querySelector('.submit-button').innerHTML = 'Salvar alterações <span>↗</span>';
    openDialog('register-dialog');
  }));
  table.querySelectorAll('[data-remove-user]').forEach(button => button.addEventListener('click', () => {
    users.splice(Number(button.dataset.removeUser), 1);
    renderUsers();
    notify('Cadastro removido desta sessão.');
  }));
}
function openDialog(id) {
  document.querySelectorAll('dialog[open]').forEach(dialog => dialog.close());
  document.getElementById(id)?.showModal();
}
document.querySelectorAll('[data-open]').forEach(button => button.addEventListener('click', () => {
  const parent = button.dataset.closeParent;
  if (parent) document.getElementById(parent).close();
  openDialog(button.dataset.open);
}));
document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
document.querySelectorAll('dialog').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); }));
document.querySelector('#register-dialog').addEventListener('close', () => {
  if (editingUser === null) return;
  editingUser = null;
  const form = document.querySelector('#register-form');
  form.reset(); form.querySelector('h2').textContent = 'Cadastrar pessoa'; form.querySelector('.submit-button').innerHTML = 'Criar cadastro <span>↗</span>';
});
document.querySelector('#register-form').addEventListener('submit', event => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form));
  const duplicate = users.findIndex((user, index) => user.email.toLowerCase() === data.email.toLowerCase() && index !== editingUser);
  if (duplicate !== -1) { notify('Já existe um cadastro com este e-mail nesta sessão.'); return; }
  if (editingUser === null) users.push(data); else users[editingUser] = data;
  renderUsers(); form.reset(); document.querySelector('#register-dialog').close();
  editingUser = null;
  form.querySelector('h2').textContent = 'Cadastrar pessoa'; form.querySelector('.submit-button').innerHTML = 'Criar cadastro <span>↗</span>';
  notify('Cadastro atualizado nesta sessão. Integre uma API para persistência segura.');
});
document.querySelector('#login-form').addEventListener('submit', event => {
  event.preventDefault();
  notify('Autenticação indisponível: conecte o formulário a uma API segura.');
});
document.querySelector('#recover-form').addEventListener('submit', event => {
  event.preventDefault();
  notify('Recuperação indisponível: configure o serviço de e-mail e a API.');
});
document.querySelector('#add-sector').addEventListener('click', () => openDialog('sector-dialog'));
document.querySelector('#sector-form').addEventListener('submit', event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget));
  if (matrix.some(row => row.name.toLowerCase() === data.name.trim().toLowerCase())) { notify('Este setor já existe na matriz.'); return; }
  matrix.forEach(row => row.values.push(0));
  matrix.push({ name: data.name.trim(), demand: Number(data.demand), values: Array(matrix.length + 1).fill(0) });
  event.currentTarget.reset(); document.querySelector('#sector-dialog').close(); renderMatrix(); notify('Setor adicionado à matriz.');
});
document.querySelector('#reset-matrix').addEventListener('click', () => {
  matrix.splice(0, matrix.length, ...structuredClone(initialMatrix));
  renderMatrix(); notify('Matriz restaurada aos dados de referência.');
});
document.querySelectorAll('.side-nav a').forEach(link => link.addEventListener('click', () => {
  document.querySelectorAll('.side-nav a').forEach(item => item.classList.remove('active'));
  link.classList.add('active');
}));
renderMatrix();